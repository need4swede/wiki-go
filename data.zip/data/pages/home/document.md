<img src="https://neptuneplayer.b-cdn.net/assets/icons/icon.png" alt="Neptune Logo" width="250" align="center" style="margin: 1.5rem auto; margin-bottom: 0; max-width: 100%;">
<br clear="all">
<h4 style="text-align:center; margin-top: 0;">Neptune is a Jellyfin client, written in Swift and designed natively for tvOS</h4>

## Quick Start

1. **[Installation](/getting-started/installation)** - Install Neptune on your device
2. **[Setup](/getting-started/setup)** - Connect to your Jellyfin server
3. **[Navigation](/getting-started/navigation)** - Learn the basics of getting around

## Getting Help

If you encounter issues:

- Check the relevant documentation page
- Share your troubles in the <a href="https://discord.gg/HTuf4HPMbP" target="_blank">Discord</a>
