---
order: 10
---

# Built-in Themes

Neptune includes seven built-in themes.



## Ocean (Default)

Deep blue underwater aesthetic with animated effects.

- **Style**: Calming, immersive
- **Background**: Animated with light rays, particles, caustics
- **Accent**: Teal/cyan
- **Best for**: Dark rooms, cinematic feel



## Midnight

Rich purples and deep blues.

- **Style**: Dark, evening
- **Background**: Animated purple gradient
- **Accent**: Purple/violet
- **Best for**: Evening viewing



## Mint

Fresh teal and purple combination.

- **Style**: Modern, vibrant
- **Background**: Animated teal gradient
- **Accent**: Mint green
- **Best for**: Bright, energetic interface



## Void

True black optimized for OLED displays.

- **Style**: Minimal, high-contrast
- **Background**: Flat black (no animation)
- **Accent**: Subtle gray
- **Best for**: OLED TVs, power saving



## Nordic

Cool grays and icy blues.

- **Style**: Clean, minimal
- **Background**: Animated icy gradient
- **Accent**: Ice blue
- **Best for**: Clean, modern aesthetic



## Volcano

Warm reds and oranges.

- **Style**: Bold, energetic
- **Background**: Animated warm gradient
- **Accent**: Orange/red
- **Best for**: Action movies, warm ambiance



## Nebula

Cosmic pinks and oranges with a deep violet base.

- **Style**: Dreamy, vibrant
- **Background**: Animated nebula gradient
- **Accent**: Pink/magenta
- **Best for**: Bold, atmospheric viewing
