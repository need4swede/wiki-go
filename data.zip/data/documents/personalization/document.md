---
order: 60
---

# Personalization

Customize how Neptune looks and which profiles use it.



## In This Section

| Page | Description |
|------|-------------|
| [Profiles](/personalization/profiles) | Multiple users, switching, preferences |
| [Themes](/personalization/themes) | Built-in and custom themes |



## Profiles

Each user gets separate:

- Watch history and progress
- Favorites and recommendations
- Theme preference

Switch profiles from Settings.



## Themes

Seven built-in themes (from Ocean to Void), plus an in-app Theme Builder for custom designs.

- Live preview as you browse
- Per-profile preferences
- **Theme Mode**: Static, Adaptive (subtle content tinting), or Dynamic (full color extraction from focused content)
- **Theme Builder**: Build your own theme on the Apple TV
- Custom theme import via JSON



## Backdrop Settings

Control how backdrops appear throughout Neptune:

- **Show Backdrops on Hover**: Toggle backdrop display when focusing cards
- **Backdrop Opacity**: Adjust theme overlay transparency (0% = full backdrop, 100% = full theme)

These settings affect both the hero spotlight and hover backdrops on content cards.



## Quick Tips

- **OLED TVs**: Use Void theme for true blacks
- **Quick switch**: Previously logged-in profiles switch right away
- **Preview themes**: Focus on themes to see them live
- **Backdrop depth**: Spotlight backdrop has parallax scrolling
