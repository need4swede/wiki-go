---
order: 30
---

# Navigation

Neptune uses a pill-shaped menu bar at the top of the screen.

---

![home-spotlight.jpg](home-spotlight.jpg)



## Tab Menu Bar

| Tab | Description |
|-----|-------------|
| **Settings** (gear) | App settings and profiles |
| **Home** | Personalized content hub |
| **Movies** | Movie library |
| **Shows** | TV show library |
| **Library** | Browse and filter your full collection |
| **Discover** | Browse and request (Jellyseerr) |
| **Search** (magnifying glass) | Find content |

**Behavior:** Tabs select on focus. No need to press Select.



## Remote Controls

| Action | Control |
|--------|---------|
| Move focus | Swipe or D-pad |
| Select | Press Touch Surface |
| Go back | Menu button |
| Return to Home | Long-press Menu |
| Open Compass | Play/Pause button |



## Compass

Press **Play/Pause** anywhere to open the [Compass](/getting-started/navigation/compass), a floating pill for tab switching without scrolling to the top.

See [Compass](/getting-started/navigation/compass) for full details.



## Hero Spotlight Navigation

The spotlight area at the top of Home, Movies, and Shows has an invisible focus zone:

| Action | Control |
|--------|---------|
| Next item | Swipe right |
| Previous item | Swipe left |
| View details | Press Select |

When focused, navigation arrows appear on the left and right edges. The spotlight auto-rotates every 8 seconds when not interacting.



## Content Tabs

**Home:** Hero spotlight, Continue Watching, Next Up, recommendations.

**Movies:** Movie-only spotlight and content rows.

**Shows:** TV-only spotlight and content rows.

**Library:** Full collection with filtering sidebar (genres, years, ratings, resolution, semantic tags).

**Discover:** Trending content, requests (requires Jellyseerr).

**Search:** Instant library search with Jellyseerr results.



## Focus Behavior

- **Menu bar:** Swipe up to reach, tabs select on focus
- **Spotlight zone:** Swipe down from menu to focus, left/right to navigate items
- **Content cards:** Swipe down to browse rows, focused cards show backdrop
- **Scrolling:** Spotlight backdrop fades with parallax as you scroll down



## Home Menu

Long-press any tab to access:

- Section customization
- Edit mode for reordering
- Quick settings shortcuts
