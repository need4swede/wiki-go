---
order: 10
---

# Compass

The Compass is a floating navigation pill that lets you switch tabs from anywhere in the app, without scrolling back up to the top menu bar.

---



## How to Use

Press the **Play/Pause** button on your Siri Remote to open the Compass. A pill-shaped overlay appears in the center of the screen showing all available tabs as icons.

| Action | Control |
|--------|---------|
| Open Compass | Play/Pause button |
| Navigate between tabs | Swipe left or right |
| Switch to selected tab | Press Touch Surface |
| Close without switching | Play/Pause or Menu button |



## Available Tabs

The Compass displays all tabs in order:

| Icon | Tab |
|------|-----|
| Gear | Settings |
| House | Home |
| Film | Movies |
| TV | Shows |
| Books | Library |
| Binoculars | Discover |
| Magnifying Glass | Search |

Your current tab is highlighted with the accent color. When the Compass opens, focus starts on your current tab.



## When to Use It

The Compass is especially useful when you're:

- **Deep in navigation.** Viewing an item's details, cast member, or collection.
- **Browsing content rows.** Scrolled far down the page.
- **Switching contexts.** Want to check another tab and return.

Instead of pressing Menu multiple times or scrolling up to the tab bar, one press of Play/Pause gives you direct access to any tab.



## Animations

**Opening:** The pill scales up from the center, first vertically then horizontally, with content fading in last.

**Closing (cancel):** When dismissed with Menu or Play/Pause, the pill collapses back to the center.

**Closing (selection):** When you select a tab, everything fades out quickly before navigating.



## Video Playback

The Compass is disabled during video playback so the Play/Pause button controls your video.

To access the Compass while a video is playing, first exit the player by pressing Menu.



## Tips

- **Quick glance:** Open the Compass just to see which tab you're on. The highlighted icon tells you.
- **Cancel safely:** Changed your mind? Press Play/Pause again or Menu to close without switching.
- **Works everywhere:** The Compass is available on any screen except during video playback.
