---
order: 30
---

# Playback Quality

How Trident keeps audio and video in sync, manages buffers, and handles seeks.



## Audio/Video Sync

Trident uses audio as the master timing reference. Video frames are displayed at the position they should appear relative to the audio.

### Calibration

When playback begins, Trident calibrates sync for your specific output. Calibration takes 1–2 seconds and runs in the background.

### Drift Correction

Over the course of a long movie, audio and video can drift apart. Trident measures the offset continuously and corrects it as you watch.



## Buffering

Trident maintains a buffer ahead of the current position so playback continues through brief network slowdowns.

### Buffer Strategy

Buffer size adapts to your network:

| Network | Strategy |
|---------|----------|
| Fast (>50 Mbps) | Quick startup, small buffer |
| Medium | Balanced buffer size |
| Slow (<10 Mbps) | Larger buffer for stability |

### During Buffering

If playback has to pause to fill the buffer, sync stays intact. When playback resumes, audio and video are still aligned.



## Seeking

Trident seeks to the exact frame you requested, not just the nearest keyframe.

### Sync After a Seek

Sync recalibrates over the first 1–2 seconds after a seek. This is when calibration is happening rather than a problem.

### Lossless Audio

With Dolby TrueHD or DTS-HD MA, expect a brief silence (~100–200ms) after a seek while the audio decoder finds a sync point. This is a property of the format, not Neptune.



## Transcoded Streams

In Transcode mode, the server may begin sending audio slightly before video. Trident detects and compensates for the offset during calibration.



## Video Caching

With **Settings > Playback > Full Video Caching** enabled, Trident caches content to disk as you stream using 6 parallel connections. Pausing continues the download in the background. This helps most on high-latency networks where parallel connections improve throughput.



## 4K HDR

4K HDR content uses hardware decoding. Dolby Vision content plays through the same path.



## Troubleshooting

### Audio Seems Out of Sync

- Wait 1–2 seconds. Calibration runs at the start of every playback session.
- Try seeking. A seek triggers a fresh calibration.

### Frequent Buffering

- Run a speed test against your Jellyfin server.
- Use Ethernet rather than Wi-Fi for high-bitrate content.
- Increase buffer size in **Settings > Playback**.

### Stuttering

- For 4K content, use the High Quality buffer preset.
- Check your network can sustain the bitrate.
- If the network can't keep up, switch to Transcode mode at a lower bitrate.
