---
order: 40
---

# Search

Neptune ships with three search technologies that run side by side: a local index for keyword matching, semantic tags for thematic searches, and an LLM-powered prompt search for plain-English queries.



## In This Section

| Page | Description |
|------|-------------|
| [Local Index Search](/search/local-index) | Offline-capable instant search |
| [Semantic Search](/search/semantic-search) | Pre-computed thematic analysis |
| [Prompt Search](/search/prompt-search) | LLM-powered conceptual search |



## The Three Technologies

| Technology | Speed | Network | Best For |
|------------|-------|---------|----------|
| **Local Index** | < 50ms | Offline | Titles, names, genres, keywords |
| **Semantic Search** | < 50ms | Offline | Themes, tone, conceptual matches |
| **Prompt Search** | 1-10s | Required | Complex queries, plot descriptions |

Local Index and Semantic Search return results as you type. Prompt Search runs when you press the sparkle button and handles longer LLM queries.



## Neptune AI

Neptune includes a built-in AI provider called **Neptune AI** that powers Prompt Search and Semantic Analysis. It's enabled by default for new users and needs no configuration.

If you'd rather use a self-hosted or third-party provider, Neptune also supports Ollama, LM Studio, OpenAI, Anthropic, Google Gemini, OpenRouter, and Zhipu GLM.



## Local Index Search

Neptune builds a complete search database on your device. Unlike native Jellyfin search which calls the server API, Local Index Search works entirely offline with instant results.

### Why Local Index?

| Feature | Local Index | Jellyfin API |
|---------|-------------|--------------|
| **Speed** | < 50ms | 200-500ms+ |
| **Offline** | Yes | No |
| **Typo tolerance** | "spi" → Spider-Man | Exact match |
| **Genre synonyms** | "sci-fi" → Science Fiction | Exact only |
| **Composer search** | Enriched from TMDb | Often missing |

### What's Indexed

| Category | Examples |
|----------|----------|
| **Titles** | "Spider-Man", "spiderman", "spider man" |
| **Genres** | "sci-fi", "scary", "funny" with synonyms |
| **People** | Cast, directors, writers, composers |
| **Studios** | Production companies |
| **Plot** | Full descriptions and overviews |

[Learn more about Local Index Search →](/search/local-index)



## Semantic Search

Neptune ships bundled with semantic tags for both movies and TV shows.

### Bundled Tags

- **4,000+ items** pre-analyzed and included
- Matched by TMDb ID for accuracy
- Works offline, no LLM needed
- Additional items can be analyzed with language models

### Example Results

| Query | Instant Matches |
|-------|-----------------|
| "time travel" | Back to the Future, Interstellar, Tenet |
| "feel-good" | Forrest Gump, The Pursuit of Happyness |
| "dystopian" | The Hunger Games, Blade Runner, 1984 |
| "heist" | Ocean's Eleven, The Italian Job |

[Learn more about Semantic Search →](/search/semantic-search)



## Prompt Search

Ask for what you want in plain English. The language model understands natural language and translates it into precise search queries.

### Example Queries

| Query | What Happens |
|-------|--------------|
| "movie about a killer shark" | LLM identifies "Jaws" |
| "farm boy learns magic fights dad" | LLM identifies "Star Wars" |
| "90s action movies" | Filters by year 1990-1999 + genre |
| "movies I haven't seen" | Filters to unwatched only |
| "composed by John Williams" | Filters by composer role |

### How It Works

1. Your query goes to configured LLM provider
2. Language model identifies likely titles and extracts filters
3. Results searched in your local library
4. Structured filters applied

[Learn more about Prompt Search →](/search/prompt-search)



## Using Search

1. Navigate to the **Search** tab
2. **Search field**: Type for Local Index + Semantic Search (instant)
3. **Sparkle button**: Prompt Search for LLM-powered queries

Results appear organized by category as you type.



## Result Categories

| Category | Description |
|----------|-------------|
| **Movies** | Films in your library |
| **TV Shows** | Series in your library |
| **Episodes** | Individual episodes (grouped by series) |
| **Collections** | Box sets matching your query |
| **Jellyseerr** | Requestable content not in library |



## Result Layouts

Choose your preferred display using the layout button:

| Layout | Description |
|--------|-------------|
| **Grouped** | Results organized by category (default) |
| **Sections** | Horizontal scrolling rows |
| **Grid** | Unified grid view |



## Jellyseerr Integration

When Jellyseerr is connected, search includes requestable content:

- Movies and TV shows not in your library
- Status badges show pending/processing state
- Select to view details and request
- Already-available items are excluded



## Configuration

Configure in **Settings** > **Search**:

| Setting | Description |
|---------|-------------|
| **Local Index** | Enable/disable, manual resync |
| **Semantic Search** | Enable pre-computed semantic tags |
| **Generate New Tags** | LLM analysis for items without tags |
| **Prompt Search** | Toggle LLM-powered query interpretation |

LLM features are powered by **Neptune AI** by default (no configuration required). Alternative providers (Ollama, LM Studio, OpenAI, Anthropic, Google Gemini, OpenRouter, Zhipu GLM) can be configured in **Settings** > **Search**.



## Privacy

| Feature | Data Location |
|---------|---------------|
| **Local Index** | Stored on device |
| **Semantic Tags** | Stored on device |
| **Prompt Search** | Queries sent to LLM provider |
| **Library content** | Never uploaded |
